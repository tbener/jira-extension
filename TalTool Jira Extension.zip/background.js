import { SettingsService } from './services/settingsService.js';
import { NavigationService } from './services/navigationService.js';
import { IssuesLists } from "./services/issuesLists.js";
import { UpdateNotificationService } from './services/updateNotificationService.js';
import { MessageActionTypes } from './enum/message-action-types.enum.js';

const DEFAULT_CUSTOM_DOMAIN = 'your-domain';
const DEFAULT_PROJECT_KEY = 'JIRA';

const settingsService = new SettingsService();
const navigationService = new NavigationService();
const issuesLists = new IssuesLists();
const updateNotificationService = new UpdateNotificationService();

let isInitialized = false;

chrome.runtime.onInstalled.addListener(function (details) {
    // Check if the extension is newly installed
    if (details.reason === chrome.runtime.OnInstalledReason.INSTALL) {
        // Save default settings or perform any necessary setup
        saveDefaultSettings();
        chrome.tabs.create({ url: chrome.runtime.getURL("pages/options/options.html?welcome") });
    } else if (details.reason === chrome.runtime.OnInstalledReason.UPDATE) {
        chrome.storage.local.clear(() => {
            if (chrome.runtime.lastError) {
                console.error('Error clearing storage:', chrome.runtime.lastError);
            }
        });
    }
});

function applyDevIndicator() {
    const manifest = chrome.runtime.getManifest();
    if (manifest.name.includes('(DEV)')) {
        chrome.action.setBadgeText({ text: 'D' });
        chrome.action.setBadgeBackgroundColor({ color: '#d93025' });
    }
}

function saveDefaultSettings() {
    const customDomain = DEFAULT_CUSTOM_DOMAIN;
    const defaultProjectKey = DEFAULT_PROJECT_KEY;

    chrome.storage.sync.set(
        { customDomain, defaultProjectKey },
        () => {
            console.debug(`Default settings saved: ${customDomain}, ${defaultProjectKey}`);
        }
    );
}

async function readSettings() {
    await settingsService.readSettings();
    await navigationService.init(settingsService);
}

async function initIssuesList() {
    await issuesLists.init();
    // await issuesLists.addMyIssues();
    // await issuesLists.addIssues(navigationService.tabsService.getIssuesList(), true);
    updateOpenTabs();
    // await issuesLists.updateIssuesList();
    console.debug("Issues list initialized:", issuesLists.getList());
}

function updateOpenTabs() {
    const openTabsIssues = navigationService.tabsService.getIssuesList();
    issuesLists.mergeOpenTabsIssues(openTabsIssues);
}

async function listenToMessages() {
    console.debug("Listening to messages");

    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        console.debug('Message received:', message.action);

        switch (message.action) {
            case MessageActionTypes.NAVIGATE_TO_ISSUE:
                (async () => {
                    try {
                        console.debug("Navigation request accepted to ", message.issueKey);
                        await ensureInitialized();
                        navigationService.navigateToIssue(message.issueKey, message.stayInCurrentTab);
                        sendResponse({ status: "navigation_started" });
                    } catch (error) {
                        console.warn("Error navigating to issue:", error);
                        sendResponse({ status: "error", error: "Failed to navigate to issue" });
                    }
                })();

                return true; // Indicate an async response

            case MessageActionTypes.NAVIGATE_TO_SEARCH:
                (async () => {
                    try {
                        console.debug("Search navigation request accepted:", message.jql);
                        await ensureInitialized();
                        navigationService.navigateToSearch(message.jql, message.stayInCurrentTab);
                        sendResponse({ status: "navigation_started" });
                    } catch (error) {
                        console.warn("Error navigating to search:", error);
                        sendResponse({ status: "error", error: "Failed to navigate to search" });
                    }
                })();

                return true; // Indicate an async response
            case MessageActionTypes.GET_SETTINGS:
                (async () => {
                    try {
                        console.debug("Settings requested");
                        await ensureInitialized();
                        sendResponse({ settings: settingsService.settings });
                    } catch (error) {
                        console.warn("Error returning settings from background listener:", error);
                        sendResponse({ error: "Failed to return settings" });
                    }
                })();

                return true; // Indicate an async response

            case MessageActionTypes.SAVE_SETTINGS:
                (async () => {
                    try {
                        console.debug("Settings save requested", message.settings);
                        await ensureInitialized(message.refreshAll);
                        await settingsService.saveSettings(message.settings);
                        sendResponse({ settings: settingsService.settings });
                    } catch (error) {
                        console.warn("Error saving settings:", error);
                        sendResponse({ error: "Failed to save settings" });
                    }
                })();

                return true; // Indicate an async response

            case MessageActionTypes.SETTINGS_CHANGED:
                (async () => {
                    try {
                        console.debug("Settings changed");
                        await ensureInitialized(true);
                        sendResponse({ settings: settingsService.settings });
                    } catch (error) {
                        console.warn("Error re-initializing:", error);
                        sendResponse({ error: "Failed to reload settings" });
                    }
                })();

                return true;
                
            case MessageActionTypes.GET_OPEN_TABS_ISSUES:
                console.debug("Open tabs issues requested");
                const openTabsIssues = navigationService.tabsService.getIssuesList();
                sendResponse({ issueKeys: openTabsIssues });
                break;
            case MessageActionTypes.GET_ISSUES_LIST:
                (async () => {
                    try {
                        console.debug("Issues list requested");
                        await ensureInitialized();
                        updateOpenTabs();
                        sendResponse({ issuesList: issuesLists.getList() });
                    } catch (error) {
                        console.warn("Error fetching issues list:", error);
                        sendResponse({ error: "Failed to fetch issues list" });
                    }
                })();

                return true; // Indicate an async response
            case MessageActionTypes.REFRESH_ISSUES_LIST:

                (async () => {
                    try {
                        console.debug("Issues list refresh requested");
                        await ensureInitialized();
                        await issuesLists.updateIssuesList();
                        sendResponse({ issuesList: issuesLists.getList() });
                    } catch (error) {
                        console.warn("Error refreshing issues list:", error);
                        sendResponse({ error: "Failed to refresh issues list" });
                    }
                })();

                return true; // Indicate an async response
            
            case MessageActionTypes.TOGGLE_FAVORITE:
                (async () => {
                    try {
                        console.debug("Toggle favorite requested for:", message.issueKey);
                        await ensureInitialized();
                        const isFavorite = await issuesLists.toggleFavorite(message.issueKey);
                        sendResponse({ isFavorite, issuesList: issuesLists.getList() });
                    } catch (error) {
                        console.warn("Error toggling favorite:", error);
                        sendResponse({ error: "Failed to toggle favorite" });
                    }
                })();

                return true; // Indicate an async response
            
            case "getUpdateMessage":
                (async () => {
                    try {
                        console.debug("Update message requested");
                        await ensureInitialized();
                        const shouldShow = await updateNotificationService.shouldShowUpdateMessage();
                        if (shouldShow) {
                            const updateMessage = await updateNotificationService.getUpdateMessage();
                            sendResponse({ shouldShow: true, updateMessage });
                        } else {
                            sendResponse({ shouldShow: false });
                        }
                    } catch (error) {
                        console.warn("Error getting update message:", error);
                        sendResponse({ shouldShow: false, error: "Failed to get update message" });
                    }
                })();

                return true; // Indicate an async response
            
            case MessageActionTypes.SWITCH_TO_EXISTING_TAB:
                console.debug("Closing this tab, switching to existing tab:", message.existingTabId);
                if (sender.tab?.id) {
                    chrome.tabs.remove(sender.tab.id);
                }
                chrome.tabs.update(message.existingTabId, { active: true }, () => {
                    chrome.tabs.get(message.existingTabId, (existingTab) => {
                        if (existingTab) {
                            chrome.windows.update(existingTab.windowId, { focused: true });
                        }
                    });
                });
                break;

            case "markUpdateAsSeen":
                (async () => {
                    try {
                        console.debug("Marking update as seen");
                        await ensureInitialized();
                        await updateNotificationService.markVersionAsSeen();
                        sendResponse({ success: true });
                    } catch (error) {
                        console.warn("Error marking update as seen:", error);
                        sendResponse({ success: false, error: "Failed to mark update as seen" });
                    }
                })();

                return true; // Indicate an async response
        }

        return true; // Ensure async handling
    });
}

async function ensureInitialized(force) {
    if (!isInitialized || force) {
        console.log(`************  Initializing background script... [${new Date().toISOString()}] ************`);
        await readSettings();
        await initIssuesList();
        await updateNotificationService.init();
        isInitialized = true;
        console.log(`++++++++++++ Background script initialized. [${new Date().toISOString()}] ++++++++++++`);
    }
}


(async () => {
    console.debug('Starting background service...');
    applyDevIndicator();
    await listenToMessages();
    await ensureInitialized();
})();
