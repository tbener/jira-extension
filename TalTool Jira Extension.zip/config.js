export const CONFIG = {
    MAX_RESULTS: 10
};